#David Centeno
#5001 Intensive Foundations
#Spring 2021

## Version 3.0 ##

import turtle_interpreter

class Shape:
    def __init__(self, distance = 100, angle = 90, color = (0, 0, 0), istring = '' ):
    # create a field of self called distance and assign it distance
        self.distance = distance
    # create a field of self called angle and assign it angle
        self.angle = angle
    # create a field of self called color and assign it color
        self.color = color
    # create a field of self called string and assign it istring
        self.string = istring
    
    # setColor(self, c) - set the color field to c
    def setColor(self,c):
        self.color = c
    # setDistance(self, d) - set the distance field to d
    def setDistance(self,d):
        self.distance = d 
    # setAngle(self, a) - set the angle field to a
    def setAngle(self,a):
        self.angle = a
    # setString(self, s) - set the string field to s
    def setString(self, s):
        self.string = s
    
    #draw function
    def draw(self, xpos, ypos, scale=1.0, orientation=0):
      # Sets ti to use the TurtleInterpreter from the turtle)interpreter.py file
        ti = turtle_interpreter.TurtleInterpreter() 
      # Uses the turtle interpreter class place method to set the position of this Class
        ti.place(xpos,ypos,orientation)
      # Uses the turtle interpreter class setcolor method to set the color of this Class
        ti.setColor(self.color)
      # Uses the turtle interpreter class drawstring method to draw the string of this Class
        ti.drawString(self.string, self.distance * scale ,self.angle)
     
    
    #method that holds up the drawing canvas of the turtle class
    def hold(self):
        turtle_interpreter.TurtleInterpreter.hold(self)

#Class that makes a square using a set L-System string
class Square(Shape):
    def __init__(self, distance=100, color=(0, 0, 0) ):
        #Borrowing init function from the parent class shape to set distance,
        #angle, color and istring
        Shape.__init__(self,100,90,color,'F-F-F-F-')

#Class that creates a triangle using a set L-system string
class Triangle(Shape):
    #Triangles init function
    def __init__(self, distance=100, color=(0, 0, 0) ):
        #Borrowing init function from the parent class shape to set distance,
        #angle, color and istring
        Shape.__init__(self,100,120,color,'F-F-F-')

class Hexagon(Shape):
    #Hexagon init function
    def __init__(self,distance=100, color=(50,100,50)):
        Shape.__init__(self,100,120, 'F-F-F-F-F-F-')
